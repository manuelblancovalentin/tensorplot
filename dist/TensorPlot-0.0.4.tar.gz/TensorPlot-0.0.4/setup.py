from setuptools import setup

setup(
    name='TensorPlot',
    version='0.0.4',
    packages=['tensorplot'],
    url='http://github.com/manuelblancovalentin/tensorplot',
    license='GPL',
    include_package_data=True,
    author='Manu Blanco Valentin',
    author_email='manuel.blanco.valentin@gmail.com',
    description=''
)
