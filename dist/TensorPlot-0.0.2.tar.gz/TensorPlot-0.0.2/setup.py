from setuptools import setup

setup(
    name='TensorPlot',
    version='0.0.2',
    packages=['tensorplot'],
    url='http://github.com/manuelblancovalentin/tensorplot',
    license='GPL',
    author='Manu Blanco Valentin',
    author_email='manuel.blanco.valentin@gmail.com',
    description=''
)
